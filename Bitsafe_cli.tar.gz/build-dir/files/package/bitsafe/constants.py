# -*- coding: utf-8 -*-


CLI_VERSION = "BitSafe CLI 1.0.0"
INI_FILE = "bitsafe.ini"
PUBLIC_KEY_PATH = "public_key.pem"
PRIVATE_KEY_PATH = "private_key.pem"
PASSWORD_PIN = ""