# -*- coding: utf-8 -*-

from bitsafe.bitsafe_cli import BitSafeCLI

if __name__ == "__main__":
    bsafe = BitSafeCLI()