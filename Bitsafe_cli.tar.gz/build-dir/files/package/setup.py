# -*- coding: utf-8 -*-
#!/usr/bin/env python
from setuptools import setup, find_packages
#
setup(
    name='bitsafe',
    version='1.0',
    description='Bitsafe - CLI',
    author='francivaldo costa reis',
    author_email='dev@francivaldo.com.br',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 1 - Planning',
    ],
    install_requires=[],
)