#!/bin/sh

export PYTHONPATH="/app/packages/bitsafe"

python3 -m bitsafe